// Square a number entered by the user

#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int i;
    do
    {
        i = get_int("Pick a number between 0 and 12, and I'll square it for you: ");
    }
    while (i < 0 || i > 12);

    // There's room for design improvement on lines 16-67
    if (i == 0)
    {
        printf("0 * 0 = 0\n");
    }
    else if (i == 1)
    {
        printf("1 * 1 = 1\n");
    }
    else if (i == 2)
    {
        printf("2 * 2 = 4\n");
    }
    else if (i == 3)
    {
        printf("3 * 3 = 9\n");
    }
    else if (i == 4)
    {
        printf("4 * 4 = 16\n");
    }
    else if (i == 5)
    {
        printf("5 * 5 = 25\n");
    }
    else if (i == 6)
    {
        printf("6 * 6 = 36\n");
    }
    else if (i == 7)
    {
        printf("7 * 7 = 49\n");
    }
    else if (i == 8)
    {
        printf("8 * 8 = 64\n");
    }
    else if (i == 9)
    {
        printf("9 * 9 = 81\n");
    }
    else if (i == 10)
    {
        printf("10 * 10 = 100\n");
    }
    else if (i == 11)
    {
        printf("11 * 11 = 121\n");
    }
    else if (i == 12)
    {
        printf("12 * 12 = 144\n");
    }
}